package bus;

public interface Ipayabl {
	public abstract double calPay();
}
